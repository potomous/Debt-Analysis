import dash
from dash import html
from layout import serve_layout
from callbacks import register_callbacks

app = dash.Dash(__name__)
app.title = "European Bank Debt Dashboard"
app.layout = serve_layout()
register_callbacks(app)

if __name__ == "__main__":
    app.run_server(debug=True)