import pandas as pd
from datetime import datetime, timedelta
import random

def fetch_mock_bond_data():
    # Simulated bond data for demonstration
    banks = ['HSBC', 'BNP Paribas', 'Santander']
    base_date = datetime.today()
    data = []

    for bank in banks:
        for i in range(3):
            issue_date = base_date - timedelta(days=random.randint(200, 1200))
            maturity_date = issue_date + timedelta(days=random.randint(1000, 3000))
            spread = random.randint(120, 200)
            coupon = round(random.uniform(1.5, 3.5), 2)
            size = random.randint(1000, 2000)
            rating = random.choice(['A', 'A-', 'BBB+', 'BBB'])

            data.append({
                'Bank': bank,
                'ISIN': f'{bank[:2].upper()}{random.randint(1000000000,9999999999)}',
                'Maturity Date': maturity_date.strftime('%Y-%m-%d'),
                'Coupon (%)': coupon,
                'Issue Size (EURm)': size,
                'Spread (bps)': spread,
                'Credit Rating': rating,
                'Issue Date': issue_date.strftime('%Y-%m-%d')
            })

    return pd.DataFrame(data)