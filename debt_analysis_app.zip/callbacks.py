from dash import Input, Output
import pandas as pd
import plotly.graph_objs as go

def register_callbacks(app):
    @app.callback(
        Output("3d-spread-curve", "figure"),
        Input("3d-spread-curve", "id")
    )
    def update_spread_curve(_):
        df = pd.read_csv("sample_bank_debt_data.csv")
        df['Maturity Date'] = pd.to_datetime(df['Maturity Date'])
        df['Issue Date'] = pd.to_datetime(df['Issue Date'])

        # Generate 3D plot
        fig = go.Figure(data=[go.Scatter3d(
            x=df['Maturity Date'],
            y=df['Spread (bps)'],
            z=df['Issue Date'],
            mode='markers',
            marker=dict(
                size=8,
                color=df['Coupon (%)'],
                colorscale='Viridis',
                opacity=0.8
            ),
            text=df['Bank']
        )])
        fig.update_layout(
            scene=dict(
                xaxis_title='Maturity Date',
                yaxis_title='Spread (bps)',
                zaxis_title='Issue Date'
            ),
            margin=dict(l=0, r=0, b=0, t=40)
        )
        return fig