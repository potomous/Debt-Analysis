from dash import html, dcc
import plotly.graph_objs as go
import pandas as pd

def serve_layout():
    df = pd.read_csv("sample_bank_debt_data.csv")

    return html.Div([
        html.H1("European Bank Debt Profile", style={"textAlign": "center"}),
        dcc.Graph(id="3d-spread-curve"),
        html.Div(id="summary-table")
    ])